(() => {
  "use strict";
  const { RUNNERS, DEPTS, DEPT, other } = TP;
  const VIEWS = ["home", "orders", "review", "split", "jere", "jesica", "checkout"];
  const MAX_FRAMES = 48;
  const FLAG_TEXT = { qty: "Quantity wasn’t clear", cust: "Customer not shown, check it", cut: "Cut off in the recording", conf: "Hard to read", dup: "May be a repeat", dept: "Department is a guess" };

  /* ---------- tiny helpers ---------- */
  const lsGet = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
  const lsSet = (k, v) => { try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch {} };
  let uidN = 0;
  const uid = () => Date.now().toString(36) + (uidN++).toString(36) + Math.random().toString(36).slice(2, 6);
  const el = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === "class") e.className = v;
      else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
      else if (k === "value") e.value = v;
      else e.setAttribute(k, v === true ? "" : v);
    }
    for (const c of kids.flat(Infinity)) if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(String(c)));
    return e;
  };
  const icon = (d) => {
    const s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    s.setAttribute("viewBox", "0 0 24 24"); s.setAttribute("aria-hidden", "true");
    const p = document.createElementNS("http://www.w3.org/2000/svg", "path");
    p.setAttribute("d", d); s.append(p);
    return s;
  };
  const plural = (n, one, many) => `${TP.fmtQty(n)} ${n === 1 ? one : many || one + "s"}`;
  const toastEl = document.getElementById("toast");
  let toastT;
  const toast = (msg) => { toastEl.textContent = msg; clearTimeout(toastT); toastT = setTimeout(() => (toastEl.textContent = ""), 5000); };

  /* ---------- state ---------- */
  const ui = { me: lsGet("tp.me"), tripId: lsGet("tp.trip"), view: "home", q: "", openKey: null, onlyFlags: false, collapsed: {}, tier: lsGet("tp.tier") === "quick" ? "quick" : "default" };
  const cap = { db: null, sample: null, sampleReady: false, maxImages: 0 };
  const store = { mode: "loading", snap: {}, readOnly: false, stale: false };
  let deptMap = {};
  const Q = {}; // per-trip write queue
  const recs = []; // recordings waiting on this phone (never stored)
  let job = null;

  /* ---------- storage: shared db when the page has it, this phone otherwise ---------- */
  const saveLocal = () => lsSet("tp.trips", JSON.stringify(store.snap));
  function loadLocal() { try { return JSON.parse(lsGet("tp.trips") || "{}") || {}; } catch { return {}; } }
  function overlay(id) {
    const q = Q[id]; if (!q) return null;
    let o = null;
    for (const p of [q.settled, q.inflight, q.pending]) if (p) o = o ? TP.deepMerge(o, p) : p;
    return o;
  }
  function tripView(id) {
    const base = store.snap[id]; if (!base) return null;
    const o = overlay(id);
    return o ? TP.deepMerge(base, o) : base;
  }
  const cur = () => (ui.tripId ? tripView(ui.tripId) : null);
  function writeFailed(e) {
    const code = e && e.code;
    if (code === "invalid_argument" || code === "not_granted" || code === "revoked") { store.readOnly = true; toast("That didn’t save. You can view this trip but not change it."); }
    else if (code === "quota_exceeded") toast("Storage for this page is full. Delete an old trip and try again.");
    else toast("That didn’t save. Check your connection and try again.");
  }
  async function cloudWrite(fn) {
    try { return await fn(); }
    catch (e) {
      if (e && e.code === "unavailable") { await new Promise((r) => setTimeout(r, 600 + Math.random() * 600)); return fn(); }
      throw e;
    }
  }
  function patchTrip(id, patch) {
    if (store.readOnly) { toast("You can view this trip but not change it."); return; }
    const q = (Q[id] ||= { busy: false, pending: null, inflight: null, settled: null });
    q.pending = q.pending ? TP.deepMerge(q.pending, patch) : patch;
    render(); pump(id);
  }
  async function pump(id) {
    const q = Q[id];
    if (!q || q.busy || !q.pending) return;
    q.busy = true; q.inflight = q.pending; q.pending = null;
    try {
      if (store.mode === "cloud") {
        await cloudWrite(() => cap.db.doc("trips/" + id).update(q.inflight));
        q.settled = q.settled ? TP.deepMerge(q.settled, q.inflight) : q.inflight;
      } else if (store.snap[id]) { store.snap[id] = TP.deepMerge(store.snap[id], q.inflight); saveLocal(); }
    } catch (e) { writeFailed(e); }
    q.inflight = null; q.busy = false;
    render();
    if (q.pending) pump(id);
  }
  async function createTrip(data) {
    if (store.readOnly) { toast("You can view trips here but not start one."); return; }
    const id = "t" + uid();
    try {
      if (store.mode === "cloud") await cloudWrite(() => cap.db.doc("trips/" + id).set(data));
      store.snap = { ...store.snap, [id]: data };
      if (store.mode !== "cloud") saveLocal();
      openTrip(id, "orders");
    } catch (e) { writeFailed(e); render(); }
  }
  async function deleteTrip(id) {
    try {
      if (store.mode === "cloud") await cloudWrite(() => cap.db.doc("trips/" + id).delete());
      const next = { ...store.snap }; delete next[id]; store.snap = next;
      if (store.mode !== "cloud") saveLocal();
      if (ui.tripId === id) { ui.tripId = null; lsSet("tp.trip", null); }
      toast("Trip deleted.");
    } catch (e) { writeFailed(e); }
    render();
  }
  function saveDeptMap(key, dept) {
    const keys = Object.keys(deptMap);
    const m = { ...(keys.length > 400 ? Object.fromEntries(keys.slice(-300).map((k) => [k, deptMap[k]])) : deptMap), [key]: dept };
    deptMap = m;
    if (store.mode === "cloud") cap.db.doc("prefs/deptmap").set({ m }).catch(() => {});
    else lsSet("tp.deptmap", JSON.stringify(m));
  }
  const learnKey = (name) => TP.normName(name).replace(/[^a-z0-9]+/g, "_").slice(0, 80);

  /* ---------- derived data ---------- */
  const linesOf = (T) => Object.entries((T && T.lines) || {}).filter(([, l]) => l && !l.x && l.n).map(([id, l]) => ({ id, ...l })).sort((a, b) => (a.o || 0) - (b.o || 0));
  const custOf = (T, cid) => (T.cust && T.cust[cid]) || { n: "", r: "jere", t: 0 };
  const custName = (c) => c.n || "Unknown order";
  const tagLetter = (c) => "ABCDEFGHJKLMNPQRSTUVWXYZ"[(c.t || 0) % 24];
  const assignee = (T, l) => l.as || (T.owners && T.owners[l.d]) || "jere";
  const resolved = (l) => l.st === "picked" || l.st === "oos" || l.st === "subbed";
  const keyOf = (l) => TP.productKey(l.n, l.s);
  function stats(T) {
    const ls = linesOf(T);
    const s = { lines: ls.length, units: 0, got: 0, products: new Set(), flagged: 0, orders: new Set(), started: false, by: { jere: { units: 0, got: 0 }, jesica: { units: 0, got: 0 } } };
    for (const l of ls) {
      const a = s.by[assignee(T, l)];
      s.units += l.q; a.units += l.q;
      const got = resolved(l) ? l.q : l.pk || 0;
      s.got += got; a.got += got;
      s.products.add(keyOf(l)); s.orders.add(l.c);
      if (l.fl && l.fl.length) s.flagged++;
      if (l.st && l.st !== "open") s.started = true;
    }
    return s;
  }
  function workload(T, onlyOpen) {
    return TP.effort(linesOf(T).map((l) => ({ dept: l.d, key: keyOf(l), qty: l.q, open: !resolved(l) })), onlyOpen);
  }
  // Owners for the trip: full rebalance before anyone starts, afterwards only place departments that have no owner yet.
  function ownersFor(T, mode) {
    const eff = workload(T, mode === "remaining");
    const userPins = Object.fromEntries(Object.entries(T.pins || {}).filter(([d, on]) => on && eff[d] && T.owners && T.owners[d]).map(([d]) => [d, T.owners[d]]));
    if (mode === "fill") {
      const fixed = Object.fromEntries(Object.keys(eff).filter((d) => T.owners && T.owners[d]).map((d) => [d, T.owners[d]]));
      return TP.balance(eff, { pins: fixed }).owners;
    }
    return TP.balance(eff, { pins: userPins, current: T.owners || {}, stick: mode === "remaining" ? 30 : 0 }).owners;
  }

  /* ---------- adding items to a trip ---------- */
  function importItems(tripId, runner, items, src) {
    const T = tripView(tripId); if (!T) return 0;
    const patch = { cust: {}, lines: {} };
    const cust = { ...(T.cust || {}) };
    let tagN = Object.keys(cust).length;
    const cidFor = (name) => {
      const hit = Object.entries(cust).find(([, c]) => c.r === runner && TP.custEq(c.n, name));
      if (hit) return hit[0];
      const cid = "c" + uid();
      cust[cid] = patch.cust[cid] = { n: name, r: runner, t: tagN++ };
      return cid;
    };
    const existing = linesOf(T);
    let order = existing.reduce((m, l) => Math.max(m, l.o || 0), 0) + 1;
    for (const it of items) {
      const c = cidFor(it.customer || "");
      const key = TP.productKey(it.name, it.size);
      const fl = [...(it.flags || [])];
      if (!it.customer && !fl.includes("cust")) fl.push("cust");
      if (src !== "manual" && existing.some((l) => l.c === c && l.src !== src && keyOf(l) === key)) fl.push("dup");
      const learned = deptMap[learnKey(it.name)];
      const d = DEPT[learned] ? learned : it.dept;
      if (DEPT[learned]) { const i = fl.indexOf("dept"); if (i >= 0) fl.splice(i, 1); }
      patch.lines["l" + uid()] = { n: it.name, b: it.brand || "", s: it.size || "", q: it.qty, c, r: runner, d, a: it.aisle || "", note: it.note || "", sub: it.sub || "", cf: it.conf ?? 1, fl, src, st: "open", pk: 0, o: order++ };
      if (it.price) patch.lines[Object.keys(patch.lines).pop()].p = it.price;
    }
    const next = TP.deepMerge(T, patch);
    if (JSON.stringify(next).length > 230000) { toast("This trip is full. Start a new trip for more orders."); return 0; }
    patch.owners = ownersFor(next, stats(T).started ? "fill" : "auto");
    patchTrip(tripId, patch);
    return items.length;
  }

  /* ---------- recordings -> frames ---------- */
  const once = (target, ok, bad, ms) => new Promise((res, rej) => {
    const done = (fn, v) => { clearTimeout(t); target.removeEventListener(ok, onOk); bad && target.removeEventListener(bad, onBad); fn(v); };
    const onOk = () => done(res), onBad = () => done(rej, { code: "video_unreadable" });
    const t = setTimeout(() => done(rej, { code: "video_unreadable" }), ms);
    target.addEventListener(ok, onOk); bad && target.addEventListener(bad, onBad);
  });
  const readDataURL = (file) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej({ code: "video_unreadable" }); r.readAsDataURL(file); });
  async function openVideo(file) {
    const v = document.createElement("video");
    v.muted = true; v.playsInline = true; v.preload = "auto"; v.setAttribute("playsinline", ""); v.setAttribute("muted", "");
    v.style.cssText = "position:fixed;left:0;top:0;width:2px;height:2px;opacity:0;pointer-events:none";
    document.body.append(v);
    const ways = [
      async () => { const u = URL.createObjectURL(file); v.src = u; return () => URL.revokeObjectURL(u); },
      async () => { v.removeAttribute("src"); v.srcObject = file; return () => { try { v.srcObject = null; } catch {} }; },
      file.size < 45e6 && (async () => { try { v.srcObject = null; } catch {} v.src = await readDataURL(file); return () => v.removeAttribute("src"); }),
    ].filter(Boolean);
    for (const way of ways) {
      let cleanup = null;
      try {
        cleanup = await way();
        const ready = once(v, "loadeddata", "error", 9000);
        v.load();
        await ready;
        // a muted play-then-pause wakes the decoder on iPhone; wait for it so it can't race the first seek
        try { await Promise.race([v.play(), new Promise((r) => setTimeout(r, 1500))]); } catch {}
        try { v.pause(); } catch {}
        if (v.videoWidth) { const c = cleanup; return { v, cleanup: () => { c(); v.remove(); } }; }
      } catch {}
      if (cleanup) cleanup();
    }
    v.remove();
    throw { code: "video_unreadable" };
  }
  // Resolve once the seek has landed AND the decoder has presented that frame (so the canvas doesn't read a stale one).
  const seek = (v, t) => new Promise((res) => {
    let over = false, seeked = false, framed = !v.requestVideoFrameCallback;
    const fin = () => { if (!over) { over = true; clearTimeout(timer); res(); } };
    const timer = setTimeout(fin, 4000);
    if (Math.abs(v.currentTime - t) < 0.002) { setTimeout(fin, 40); return; }
    if (!framed) v.requestVideoFrameCallback(() => { framed = true; if (seeked) fin(); });
    v.addEventListener("seeked", () => { seeked = true; if (framed) fin(); else setTimeout(fin, 150); }, { once: true });
    v.currentTime = t;
  });
  const toJpeg = (canvas) => new Promise((res, rej) => canvas.toBlob((b) => (b ? res(b) : rej({ code: "video_unreadable" })), "image/jpeg", 0.85));
  /* Pass 1 watches the recording at low resolution and notes the moments where the list has moved
     about 40% of a screen (or the screen changed). Pass 2 exports just those moments. */
  async function framesFromVideo(file, onProg, signal) {
    const { v, cleanup } = await openVideo(file);
    try {
      const dur = v.duration;
      if (!Number.isFinite(dur) || dur <= 0) throw { code: "video_unreadable" };
      const vw = v.videoWidth, vh = v.videoHeight;
      const aw = 72, ah = Math.max(48, Math.min(220, Math.round((72 * vh) / vw)));
      const ac = el("canvas", { width: aw, height: ah }), actx = ac.getContext("2d", { willReadFrequently: true });
      const step = dur > 120 ? 0.6 : dur > 45 ? 0.45 : 0.33;
      let times = [], kept = null, lastSig = null, lastT = 0;
      await seek(v, Math.min(0.4, dur / 2)); // warm-up so the first real seek lands on a decoded frame
      for (let t = 0.05; t < dur; t += step) {
        if (signal.aborted) throw { code: "cancelled" };
        await seek(v, Math.min(t, Math.max(0, dur - 0.05)));
        actx.drawImage(v, 0, 0, aw, ah);
        const sig = TP.rowSig(actx.getImageData(0, 0, aw, ah).data, aw, ah);
        const m = kept ? TP.motion(kept, sig, ah) : { kind: "change" };
        if (m.kind === "change" || (m.kind === "scroll" && m.frac >= 0.4)) { times.push(t); kept = sig; }
        lastSig = sig; lastT = t;
        onProg((t / dur) * 0.7);
      }
      if (kept && lastSig && lastT !== times[times.length - 1] && TP.motion(kept, lastSig, ah).kind !== "still") times.push(lastT);
      let thinned = false;
      if (times.length > MAX_FRAMES) { thinned = true; times = Array.from({ length: MAX_FRAMES }, (_, i) => times[Math.round((i * (times.length - 1)) / (MAX_FRAMES - 1))]); }
      const scale = Math.min(1, 1568 / Math.max(vw, vh));
      const oc = el("canvas", { width: Math.round(vw * scale), height: Math.round(vh * scale) }), octx = oc.getContext("2d");
      const frames = [];
      for (let i = 0; i < times.length; i++) {
        if (signal.aborted) throw { code: "cancelled" };
        await seek(v, Math.min(times[i], Math.max(0, dur - 0.05)));
        octx.drawImage(v, 0, 0, oc.width, oc.height);
        frames.push({ blob: await toJpeg(oc), t: times[i] });
        onProg(0.7 + (0.3 * (i + 1)) / times.length);
      }
      return { frames, thinned };
    } finally { cleanup(); }
  }

  /* ---------- frames -> items (Claude reads the stills) ---------- */
  function promptFor(rec, n) {
    return [
      `These ${n} image${n === 1 ? " is a still" : "s are consecutive stills"} from a phone screen recording of a grocery shopping list in the Favor runner app, for orders shopped at H-E-B. ${n > 1 ? `They are in order, numbered 1 to ${n}, and neighbouring stills overlap, so one list row can appear in more than one image.` : ""}`,
      "List every product row you can read. Report each distinct row once even if it shows in several stills. If the same product is listed under two different customers or orders, report it once for each.",
      "For each row give these fields:",
      '- "name": the product name exactly as shown',
      '- "brand": the brand if shown, else null',
      '- "qty": the number of units requested, as shown. If no quantity is visible use 1 and set "qtyShown" to false',
      '- "qtyShown": true or false',
      '- "size": package size or weight as shown, such as "1 gal" or "16 oz", else null',
      '- "customer": the customer name or order label this row belongs to, exactly as shown (a header, tab or label), or null if these stills do not show it',
      `- "dept": one of ${DEPTS.map((d) => d.id).join(", ")} (hb is health and beauty; prepared is refrigerated ready-to-eat food)`,
      '- "aisle": aisle or shelf location text if shown, else null',
      '- "note": the customer\'s instructions for this item if shown, else null',
      '- "sub": the substitution preference if shown, else null',
      '- "price": a number if shown, else null',
      '- "conf": 0 to 1, how sure you are that name, quantity and size are right',
      '- "cut": true if the row is cut off at the edge and never fully visible in these stills, else false',
      '- "frame": the number of the first image where the row appears',
      "Rules: report only what is visible. Never guess a size, brand, quantity or customer. Leave out addresses, phone numbers, payment details, totals and anything that is not a product row.",
      rec.label ? `The runner says this recording is the order for "${rec.label.replace(/["\\]/g, "")}". Use that as the customer unless a row clearly shows a different one.` : "",
      'Reply with only JSON in this shape: {"items":[{"name":"H-E-B Whole Milk","brand":"H-E-B","qty":2,"qtyShown":true,"size":"1 gal","customer":"Sydney","dept":"dairy","aisle":null,"note":null,"sub":null,"price":null,"conf":0.95,"cut":false,"frame":1}]}. If there are no product rows reply {"items":[]}.',
    ].filter(Boolean).join("\n");
  }
  const HALT = ["not_granted", "sampling_disabled", "not_declared", "capability_disabled", "capability_removed", "images_unavailable", "rate_limited", "session_expired", "cancelled"];
  const ERR_TEXT = {
    not_granted: "Claude isn’t allowed to read images for this page in this view.", sampling_disabled: "Claude isn’t available for this account.", images_unavailable: "This view can’t send images to Claude.",
    rate_limited: "Claude’s usage limit was reached. Wait a little, then read the remaining parts.", session_expired: "Sign in to Claude again, then read the remaining parts.", cancelled: "Stopped.",
    refused: "Claude declined to read part of this recording.", invalid_json: "Part of the answer couldn’t be used.", image_rejected: "One of the images couldn’t be used. Try a different file.",
    video_unreadable: "This browser couldn’t open the video. Screenshots of the list work too.", no_frames: "No list screens were found in this recording.",
  };
  const errText = (code) => ERR_TEXT[code] || "Something interrupted the reading.";
  async function readRec(rec, signal) {
    const K = Math.max(1, Math.min(cap.maxImages || 1, 4));
    if (!rec.batches) { rec.batches = []; for (let i = 0; i < rec.frames.length; i += K) rec.batches.push({ start: i, n: Math.min(K, rec.frames.length - i), state: "todo" }); }
    const todo = rec.batches.filter((b) => b.state !== "ok");
    let next = 0, halt = null;
    const worker = async () => {
      while (next < todo.length && !halt && !signal.aborted) {
        const b = todo[next++];
        b.state = "run"; paintRec(rec);
        try {
          const out = await cap.sample.json(promptFor(rec, b.n), { images: rec.frames.slice(b.start, b.start + b.n).map((f) => f.blob), signal, modelTier: ui.tier });
          const rows = out && Array.isArray(out.items) ? out.items : Array.isArray(out) ? out : [];
          b.items = rows.map((r) => TP.cleanItem(r, b.start)).filter(Boolean);
          b.state = "ok";
        } catch (e) {
          b.state = "err"; b.code = (e && e.code) || "upstream_error";
          if (HALT.includes(b.code)) halt = b.code;
        }
        paintRec(rec);
      }
    };
    await Promise.all([worker(), worker()]);
    return halt || (signal.aborted ? "cancelled" : null);
  }
  function finalize(rec) {
    const raw = rec.batches.filter((b) => b.state === "ok").flatMap((b) => b.items || []);
    const items = TP.fillCustomers(TP.dedupe(raw), rec.label.trim());
    rec.added = importItems(rec.tripId, rec.runner, items, rec.id);
    rec.flagged = items.filter((i) => i.flags.length).length;
    rec.state = "done"; rec.frames = null;
  }
  async function processRec(rec, signal) {
    try {
      if (!rec.frames) {
        rec.state = "frames"; rec.prog = 0; render();
        if (rec.files) rec.frames = rec.files.map((f) => ({ blob: f, t: 0 }));
        else { const r = await framesFromVideo(rec.file, (p) => { rec.prog = p; paintRec(rec); }, signal); rec.frames = r.frames; rec.thinned = r.thinned; }
        if (!rec.frames.length) throw { code: "no_frames" };
      }
      rec.state = "reading"; render();
      const halt = await readRec(rec, signal);
      if (rec.batches.every((b) => b.state === "ok")) finalize(rec);
      else { rec.state = "partial"; rec.err = halt || (rec.batches.find((b) => b.state === "err") || {}).code || "upstream_error"; if (halt) job.halt = true; }
    } catch (e) { rec.state = "failed"; rec.err = (e && e.code) || "video_unreadable"; if (rec.err === "cancelled") { rec.state = "queued"; rec.frames = null; } }
    render();
  }
  async function runJob() {
    if (job || !cap.sample) return;
    job = { ctl: new AbortController(), halt: false };
    render();
    for (const rec of recs.filter((r) => ["queued", "partial", "failed"].includes(r.state))) {
      if (job.ctl.signal.aborted || job.halt) break;
      await processRec(rec, job.ctl.signal);
    }
    job = null;
    const done = recs.filter((r) => r.state === "done" && !r.told);
    if (done.length) { done.forEach((r) => (r.told = true)); toast(`Added ${plural(done.reduce((s, r) => s + (r.added || 0), 0), "item")}. Check them on the Review screen.`); }
    render();
  }
  function recStatus(rec) {
    if (rec.state === "queued") return "Waiting to be read";
    if (rec.state === "frames") return `Finding the list screens, ${Math.round((rec.prog || 0) * 100)}%`;
    if (rec.state === "reading") { const ok = rec.batches ? rec.batches.filter((b) => b.state === "ok").length : 0; return `Claude is reading ${plural(rec.frames.length, "screen")}: part ${Math.min(ok + 1, rec.batches ? rec.batches.length : 1)} of ${rec.batches ? rec.batches.length : 1}. This can take a minute or two.`; }
    if (rec.state === "done") return `Added ${plural(rec.added || 0, "item")}${rec.flagged ? `, ${rec.flagged} to check` : ""}${rec.thinned ? ". Long recording, so some screens were skipped; check for missing items." : ""}`;
    if (rec.state === "partial") { const bad = rec.batches.filter((b) => b.state !== "ok").length; return `${errText(rec.err)} ${bad} of ${rec.batches.length} parts not read yet.`; }
    return errText(rec.err);
  }
  function paintRec(rec) { if (rec.statusEl && rec.statusEl.isConnected) rec.statusEl.textContent = recStatus(rec); }

  /* ---------- actions on lines ---------- */
  function setLines(T, ls, fields) {
    const patch = { lines: {} };
    const stamp = { by: ui.me || "", at: Date.now() };
    for (const l of ls) {
      patch.lines[l.id] = { ...fields, ...stamp };
      if (T.ver && T.ver[l.c] && T.ver[l.c].ok) (patch.ver ||= {})[l.c] = { ok: false };
    }
    if (!T.t0 && fields.st && fields.st !== "open") patch.t0 = Date.now();
    patchTrip(ui.tripId, patch);
  }
  const pick = (T, ls) => setLines(T, ls, { st: "picked", pk: 0 });
  const unpick = (T, ls) => setLines(T, ls, { st: "open", pk: 0 });
  function setPicked(T, l, n) {
    if (n <= 0) setLines(T, [l], { st: "open", pk: 0 });
    else if (n >= l.q) setLines(T, [l], { st: "picked", pk: 0 });
    else setLines(T, [l], { st: "partial", pk: n });
  }

  /* ---------- sheet ---------- */
  const sheetRoot = document.getElementById("sheet");
  function closeSheet() { sheetRoot.replaceChildren(); }
  function openSheet(title, body) {
    const sheet = el("div", { class: "sheet", role: "dialog", "aria-modal": "true", "aria-label": title }, el("h2", {}, title), body);
    const scrim = el("div", { class: "scrim", onclick: (e) => { if (e.target === scrim) closeSheet(); } }, sheet);
    sheetRoot.replaceChildren(scrim);
    const first = sheet.querySelector("input, select, textarea, button");
    if (first) first.focus();
  }
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeSheet(); });
  const field = (label, input) => el("label", { class: "field" }, el("span", {}, label), input);
  function runnerSeg(value, onPick) {
    const seg = el("div", { class: "seg", role: "group" });
    for (const r of ["jere", "jesica"]) seg.append(el("button", { type: "button", class: r, "aria-pressed": String(value === r), onclick: () => { [...seg.children].forEach((b) => b.setAttribute("aria-pressed", "false")); seg.children[r === "jere" ? 0 : 1].setAttribute("aria-pressed", "true"); onPick(r); } }, RUNNERS[r]));
    return seg;
  }

  function editLine(T, l) {
    const isNew = !l;
    const d = l ? { ...l } : { n: "", s: "", q: 1, d: "pantry", r: ui.me || "jere", c: "", note: "" };
    const name = el("input", { class: "in", value: d.n, autocomplete: "off" });
    const size = el("input", { class: "in", value: d.s, placeholder: "16 oz, 1 gal…", autocomplete: "off" });
    const qty = el("input", { class: "in", type: "number", inputmode: "decimal", min: "0.01", step: "any", value: String(d.q) });
    const dept = el("select", { class: "in" }, DEPTS.map((x) => el("option", { value: x.id, selected: x.id === d.d }, x.name)));
    const note = el("input", { class: "in", value: d.note || "", autocomplete: "off" });
    const custSel = el("select", { class: "in" });
    const custNew = el("input", { class: "in", placeholder: "Customer name", autocomplete: "off" });
    const custNewWrap = field("New customer", custNew);
    const fillCust = () => {
      custSel.replaceChildren(...Object.entries(T.cust || {}).filter(([, c]) => c.r === d.r).map(([cid, c]) => el("option", { value: cid, selected: cid === d.c }, `${tagLetter(c)}  ${custName(c)}`)), el("option", { value: "+" }, "New customer…"));
      custNewWrap.hidden = custSel.value !== "+";
    };
    custSel.addEventListener("change", () => { custNewWrap.hidden = custSel.value !== "+"; });
    fillCust();
    const save = () => {
      const n = name.value.trim(); const q = Number(qty.value);
      if (!n) { name.focus(); return; }
      if (!Number.isFinite(q) || q <= 0) { qty.focus(); return; }
      const customer = custSel.value === "+" ? custNew.value.trim() : custOf(T, custSel.value).n;
      if (custSel.value === "+" && !customer) { custNew.focus(); return; }
      if (isNew) {
        importItems(ui.tripId, d.r, [{ name: n, size: size.value.trim(), qty: q, dept: dept.value, customer, note: note.value.trim(), flags: [] }], "manual");
      } else {
        const patch = { lines: { [l.id]: { n, s: size.value.trim(), q, d: dept.value, note: note.value.trim(), fl: [], r: d.r } }, cust: {} };
        if (custSel.value === "+") { const cid = "c" + uid(); patch.cust[cid] = { n: customer, r: d.r, t: Object.keys(T.cust || {}).length }; patch.lines[l.id].c = cid; }
        else patch.lines[l.id].c = custSel.value;
        if (dept.value !== l.d) { saveDeptMap(learnKey(n), dept.value); const next = TP.deepMerge(T, patch); if (!(T.owners || {})[dept.value]) patch.owners = ownersFor(next, "fill"); }
        if (l.q !== q && l.st === "picked") patch.lines[l.id].st = "open";
        patchTrip(ui.tripId, patch);
      }
      closeSheet();
    };
    let armed = false;
    const del = !isNew && el("button", { type: "button", class: "btn danger", onclick: (e) => { if (!armed) { armed = true; e.currentTarget.textContent = "Tap again to delete"; return; } patchTrip(ui.tripId, { lines: { [l.id]: { x: 1 } } }); closeSheet(); } }, "Delete item");
    openSheet(isNew ? "Add an item" : "Check this item", el("div", { class: "stack" },
      !isNew && l.fl && l.fl.length ? el("div", { class: "banner" }, l.fl.map((f) => FLAG_TEXT[f] || f).join(". ") + ". Saving marks it as checked.") : null,
      field("Product", name),
      el("div", { class: "row" }, el("div", { style: "width:110px" }, field("Quantity", qty)), el("div", { class: "grow" }, field("Size", size))),
      field("Department", dept),
      el("div", { class: "field" }, el("span", {}, "Whose Favor order"), runnerSeg(d.r, (r) => { d.r = r; d.c = ""; fillCust(); })),
      field("Customer", custSel), custNewWrap,
      field("Customer’s note", note),
      el("div", { class: "row" }, el("button", { type: "button", class: "btn primary grow", onclick: save }, isNew ? "Add item" : "Save"), del, el("button", { type: "button", class: "btn", onclick: closeSheet }, "Cancel"))));
  }
  function renameCustomer(T, cid) {
    const c = custOf(T, cid);
    const name = el("input", { class: "in", value: c.n, autocomplete: "off" });
    openSheet("Customer name", el("div", { class: "stack" }, field(`Bag ${tagLetter(c)}, from ${RUNNERS[c.r]}’s Favor`, name),
      el("div", { class: "row" }, el("button", { type: "button", class: "btn primary grow", onclick: () => {
        const n = name.value.trim(); if (!n) { name.focus(); return; }
        const patch = { cust: { [cid]: { n } }, lines: {} };
        for (const l of linesOf(T)) if (l.c === cid && l.fl && l.fl.includes("cust")) patch.lines[l.id] = { fl: l.fl.filter((f) => f !== "cust") };
        patchTrip(ui.tripId, patch); closeSheet();
      } }, "Save"), el("button", { type: "button", class: "btn", onclick: closeSheet }, "Cancel"))));
  }
  function subSheet(T, l) {
    const what = el("input", { class: "in", value: l.sn || "", placeholder: "What you grabbed instead", autocomplete: "off" });
    const done = (st) => { setLines(T, [l], { st, pk: 0, sn: what.value.trim() }); closeSheet(); };
    openSheet("Substitution", el("div", { class: "stack" },
      el("p", {}, `${TP.fmtQty(l.q)} × ${l.n}${l.s ? ", " + l.s : ""} for ${custName(custOf(T, l.c))}`),
      l.sub ? el("div", { class: "banner plain" }, "Customer’s preference: " + l.sub) : null,
      field("Replacement", what),
      el("button", { type: "button", class: "btn primary wide", onclick: () => { if (!what.value.trim()) { what.focus(); return; } done("subbed"); } }, "Substituted, it’s in the cart"),
      el("button", { type: "button", class: "btn wide", onclick: () => done("needsub") }, "Still needs a substitute"),
      el("button", { type: "button", class: "btn quiet", onclick: closeSheet }, "Cancel")));
  }

  /* ---------- views ---------- */
  const tag = (T, cid, extra) => { const c = custOf(T, cid); return el("span", { class: `tag t${(c.t || 0) % 8}` }, el("b", {}, tagLetter(c)), el("span", {}, extra ? `${extra} ${custName(c)}` : custName(c))); };
  const bar = (frac, cls) => el("div", { class: "bar " + (cls || "") }, el("i", { style: `width:${Math.round(Math.max(0, Math.min(1, frac)) * 100)}%` }));
  const sampleNote = (T) => (T.sample ? el("div", { class: "banner plain" }, "Sample orders, made up for trying the app. Nothing here came from a recording.") : null);

  function vHome() {
    const box = el("div", { class: "stack" });
    if (!ui.me) box.append(el("div", { class: "card stack" }, el("h2", {}, "Who’s holding this phone?"), el("div", { class: "row" },
      ...["jere", "jesica"].map((r) => el("button", { class: "btn grow who-" + r, onclick: () => setMe(r) }, RUNNERS[r])))));
    box.append(el("h1", {}, "Shopping trips"));
    const ids = Object.keys(store.snap).sort((a, b) => (store.snap[b].createdAt || 0) - (store.snap[a].createdAt || 0));
    if (store.mode === "loading") box.append(el("p", { class: "muted" }, store.stale ? "Saved trips can’t be reached yet. Still trying." : "Loading trips…"));
    else if (!ids.length) box.append(el("p", { class: "muted" }, "No trips yet. Start one when you both have your orders."));
    for (const id of ids) {
      const T = tripView(id), s = stats(T);
      box.append(el("div", { class: "card stack" },
        el("div", { class: "row" }, el("h3", { class: "grow" }, T.name || "Trip"), T.sample ? el("span", { class: "pill" }, "Sample") : null, T.done ? el("span", { class: "pill ok" }, "Finished") : null),
        el("p", { class: "muted small" }, [T.store, s.lines ? `${TP.fmtQty(s.got)} of ${TP.fmtQty(s.units)} units done` : "No items yet"].filter(Boolean).join(", ")),
        s.lines ? bar(s.units ? s.got / s.units : 0) : null,
        el("div", { class: "row" }, el("button", { class: "btn grow", onclick: () => openTrip(id) }, "Open trip"), el("button", { class: "btn quiet sm", onclick: () => confirmDelete(id, T) }, "Delete"))));
    }
    if (store.mode !== "loading") {
      const storeIn = el("input", { class: "in", placeholder: "Which H-E-B? (optional)", autocomplete: "off", "data-fk": "store" });
      box.append(el("div", { class: "card stack" }, el("h2", {}, "Start a trip"), field("Store", storeIn),
        el("button", { class: "btn primary wide", disabled: store.readOnly, onclick: () => createTrip({ name: new Date().toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }), store: storeIn.value.trim().slice(0, 80), createdAt: Date.now(), by: ui.me || "", owners: {}, pins: {}, cust: {}, lines: {}, ver: {} }) }, "Start a trip"),
        el("button", { class: "btn wide", disabled: store.readOnly, onclick: () => createTrip(sampleTrip()) }, "Try it with sample orders")));
      box.append(el("p", { class: "muted small" }, store.mode === "cloud" ? (window.TP_STANDALONE ? "Trips are shared live with everyone who has the team passcode." : "Trips are shared live with everyone you’ve given edit access to this page.") : "Trips are saved on this phone only, because shared storage isn’t available in this view."));
    }
    box.append(el("p", { class: "muted small" }, "TeamPick works only from what you upload or type. It never touches Favor or its checkout. Each runner stays responsible for Favor’s policies and for customers’ privacy."));
    return box;
  }
  function confirmDelete(id, T) {
    openSheet("Delete this trip?", el("div", { class: "stack" }, el("p", {}, `${T.name || "Trip"} and its ${plural(stats(T).lines, "item")} will be removed for both of you. This can’t be undone.`),
      el("div", { class: "row" }, el("button", { class: "btn danger grow", onclick: () => { closeSheet(); deleteTrip(id); } }, "Delete trip"), el("button", { class: "btn", onclick: closeSheet }, "Keep it"))));
  }

  function vOrders(T) {
    const box = el("div", { class: "stack" }, el("h1", {}, "Add orders"), sampleNote(T));
    box.append(el("p", { class: "muted" }, "Record your screen while you scroll each Favor shopping list slowly from top to bottom, then add the recording here. Screenshots work too."));
    if (cap.sampleReady && !cap.sample) box.append(el("div", { class: "banner" }, window.TP_STANDALONE ? "Reading recordings isn’t switched on for this site yet. It needs an Anthropic API key on the server. You can add items by hand below." : "Reading recordings needs Claude, which isn’t available in this view. Open the page inside Claude, or add items by hand below."));
    else if (cap.sampleReady && !cap.maxImages) box.append(el("div", { class: "banner" }, "This view can’t send images to Claude, so recordings can’t be read here. You can add items by hand below."));
    for (const r of ["jere", "jesica"]) {
      const mine = recs.filter((x) => x.runner === r && x.tripId === ui.tripId);
      const input = el("input", { type: "file", accept: "video/*,image/*", multiple: true, "aria-label": `Add ${RUNNERS[r]}’s recordings or screenshots`, onchange: (e) => { addFiles(r, [...e.target.files]); e.target.value = ""; } });
      box.append(el("div", { class: "card " + r },
        el("h2", { class: "who-" + r }, `${RUNNERS[r]}’s Favor orders`),
        el("label", { class: "drop", style: "margin-top:10px" }, input, "Add recordings or screenshots"),
        mine.map((rec) => {
          rec.statusEl = el("p", { class: "small " + (rec.state === "failed" || rec.state === "partial" ? "flagtxt" : "muted"), "aria-live": "polite" }, recStatus(rec));
          const busy = job && (rec.state === "frames" || rec.state === "reading");
          return el("div", { class: "rec stack" },
            el("div", { class: "row" }, el("div", { class: "fn grow" }, rec.title), !busy && rec.state !== "done" ? el("button", { class: "btn quiet sm", onclick: () => { recs.splice(recs.indexOf(rec), 1); render(); } }, "Remove") : null),
            rec.state === "queued" ? field("Customer, if this is one order (optional)", el("input", { class: "in", value: rec.label, autocomplete: "off", "data-fk": "lab" + rec.id, oninput: (e) => (rec.label = e.target.value.slice(0, 60)) })) : null,
            rec.statusEl,
            rec.state === "partial" && !job ? el("div", { class: "row" }, el("button", { class: "btn sm", onclick: runJob }, "Read the remaining parts"), rec.batches.some((b) => b.state === "ok") ? el("button", { class: "btn sm", onclick: () => { finalize(rec); toast("Added what was read. Check for missing items."); render(); } }, "Add what was read") : null) : null);
        })));
    }
    const waiting = recs.filter((r) => r.tripId === ui.tripId && ["queued", "failed"].includes(r.state)).length;
    box.append(el("div", { class: "stack" },
      el("div", { class: "row" }, el("span", { class: "small muted grow" }, "Reading"), (() => { const seg = el("div", { class: "seg", role: "group", "aria-label": "Reading speed" }); for (const [v, t] of [["default", "Careful"], ["quick", "Faster"]]) seg.append(el("button", { type: "button", "aria-pressed": String(ui.tier === v), onclick: () => { ui.tier = v; lsSet("tp.tier", v); render(); } }, t)); return seg; })()),
      job ? el("button", { class: "btn wide", onclick: () => job.ctl.abort() }, "Stop reading")
        : el("button", { class: "btn primary wide", disabled: !waiting || !cap.sample || !cap.maxImages || store.readOnly, onclick: runJob }, !cap.sampleReady ? "Getting ready…" : waiting ? `Read ${plural(waiting, "upload")}` : "Add a recording to read"),
      el("button", { class: "btn wide", disabled: store.readOnly, onclick: () => editLine(T, null) }, "Add an item by hand"),
      linesOf(T).length ? el("button", { class: "btn wide", onclick: () => go("review") }, `Review ${plural(linesOf(T).length, "item")}`) : null,
      el("p", { class: "muted small" }, "Videos stay on this phone. Only still frames go to Claude to be read, with instructions to ignore addresses, phone numbers and payment details. The trip saves product rows and customer names, nothing else.")));
    return box;
  }
  function addFiles(runner, files) {
    const vids = files.filter((f) => f.type.startsWith("video/") || /\.(mp4|mov|webm|m4v)$/i.test(f.name));
    const imgs = files.filter((f) => f.type.startsWith("image/")).sort((a, b) => a.lastModified - b.lastModified || a.name.localeCompare(b.name));
    for (const f of vids) recs.push({ id: "r" + uid(), tripId: ui.tripId, runner, file: f, title: `${f.name} (${(f.size / 1e6).toFixed(1)} MB)`, label: "", state: "queued" });
    for (let i = 0; i < imgs.length; i += 24) { const g = imgs.slice(i, i + 24); recs.push({ id: "r" + uid(), tripId: ui.tripId, runner, files: g, title: g.length === 1 ? g[0].name : `${g.length} screenshots`, label: "", state: "queued" }); }
    if (!vids.length && !imgs.length && files.length) toast("That file type isn’t supported. Use a video or a screenshot.");
    render();
  }

  function vReview(T) {
    const ls = linesOf(T), flagged = ls.filter((l) => l.fl && l.fl.length);
    const box = el("div", { class: "stack" }, el("h1", {}, "Review items"), sampleNote(T));
    if (!ls.length) { box.append(el("p", { class: "muted" }, "Nothing to review yet."), el("button", { class: "btn primary wide", onclick: () => go("orders") }, "Add orders")); return box; }
    box.append(el("p", { class: "muted" }, flagged.length ? `${plural(flagged.length, "item")} of ${ls.length} need a look. Tap one to fix or confirm it.` : `All ${ls.length} items look complete. Tap any item to change it.`));
    if (flagged.length) { const seg = el("div", { class: "seg", role: "group", "aria-label": "Which items to show" }); for (const [v, t] of [[false, `All ${ls.length}`], [true, `To check ${flagged.length}`]]) seg.append(el("button", { type: "button", "aria-pressed": String(ui.onlyFlags === v), onclick: () => { ui.onlyFlags = v; render(); } }, t)); box.append(seg); }
    const show = ui.onlyFlags && flagged.length ? flagged : ls;
    for (const r of ["jere", "jesica"]) {
      const cids = Object.keys(T.cust || {}).filter((cid) => T.cust[cid].r === r && show.some((l) => l.c === cid));
      if (!cids.length) continue;
      const sec = el("div", { class: "card " + r }, el("h2", { class: "who-" + r }, `From ${RUNNERS[r]}’s Favor`));
      for (const cid of cids) {
        const mine = show.filter((l) => l.c === cid);
        sec.append(el("div", { class: "row", style: "margin-top:14px" }, el("div", { class: "grow" }, tag(T, cid)), el("span", { class: "muted small" }, plural(mine.length, "item")), el("button", { class: "btn quiet sm", onclick: () => renameCustomer(T, cid) }, "Rename")));
        for (const l of mine) sec.append(el("button", { class: "rv" + (l.fl && l.fl.length ? " flagged" : ""), onclick: () => editLine(T, l) },
          el("span", { class: "q num" }, TP.fmtQty(l.q)),
          el("span", {}, el("span", { class: "nm" }, l.n), el("br"), el("span", { class: "muted small" }, [l.s, (DEPT[l.d] || DEPT.other).name].filter(Boolean).join(", ")), l.fl && l.fl.length ? el("span", { class: "flagtxt" }, el("br"), l.fl.map((f) => FLAG_TEXT[f] || f).join(". ")) : null),
          el("span", { class: "muted small" }, "Edit")));
      }
      box.append(sec);
    }
    box.append(el("button", { class: "btn wide", disabled: store.readOnly, onclick: () => editLine(T, null) }, "Add an item by hand"), el("button", { class: "btn primary wide", onclick: () => go("split") }, "Split the work"));
    return box;
  }

  function vSplit(T) {
    const s = stats(T), box = el("div", { class: "stack" }, el("h1", {}, "Split the work"), sampleNote(T));
    if (!s.lines) { box.append(el("p", { class: "muted" }, "Add orders first, then the departments get divided here."), el("button", { class: "btn primary wide", onclick: () => go("orders") }, "Add orders")); return box; }
    const eff = workload(T, false), effOpen = workload(T, true);
    const owners = T.owners || {};
    const ids = Object.keys(eff).sort((a, b) => (DEPT[a] || DEPT.other).order - (DEPT[b] || DEPT.other).order);
    const tot = { jere: 0, jesica: 0 }, left = { jere: 0, jesica: 0 }, nd = { jere: 0, jesica: 0 };
    for (const d of ids) { const o = owners[d] || "jere"; tot[o] += eff[d].secs; left[o] += effOpen[d] ? effOpen[d].secs : 0; nd[o]++; }
    const reasons = TP.explain(ids, Object.fromEntries(ids.map((d) => [d, owners[d] || "jere"])), T.pins || {});
    const handed = linesOf(T).filter((l) => l.as).length;
    const maxT = Math.max(tot.jere, tot.jesica, 1);
    box.append(el("div", { class: "card" }, el("div", { class: "facts" },
      ...[[s.orders.size, "customer orders"], [s.products.size, "different products"], [TP.fmtQty(s.units), "units in all"], [TP.fmtQty(s.got), "units done"], [TP.fmtQty(s.units - s.got), "units left"], [s.flagged, "items to check"]].map(([n, t]) => el("div", {}, el("b", { class: "num" }, n), el("span", {}, t)))),
      T.t0 ? el("p", { class: "muted small", style: "margin-top:10px" }, `First item picked ${Math.max(0, Math.round((Date.now() - T.t0) / 60000))} min ago (measured).`) : null));
    box.append(el("div", { class: "vs" }, ...["jere", "jesica"].map((r) => el("div", { class: "card " + r },
      el("h3", { class: "who-" + r }, RUNNERS[r]), el("div", { class: "big num" }, `${TP.mins(tot[r])} min`),
      el("p", { class: "muted small" }, `${plural(nd[r], "department")}, ${plural(s.by[r].units, "unit")}`), el("div", { style: "margin-top:8px" }, bar(tot[r] / maxT, r)),
      s.started ? el("p", { class: "muted small", style: "margin-top:6px" }, `About ${TP.mins(left[r])} min left`) : null))));
    box.append(el("p", { class: "muted small" }, "Minutes are rough estimates from item counts and typical counter waits, not measurements, and they don’t know this store’s layout."));
    const list = el("div", { class: "card" });
    for (const d of ids) {
      const def = DEPT[d] || DEPT.other, o = owners[d] || "jere";
      list.append(el("div", { class: "drow" },
        el("div", {}, el("div", { class: "dn" }, `${def.icon} ${def.name}`), el("div", { class: "muted small" }, `${plural(eff[d].products, "product")}, ${plural(eff[d].units, "unit")}, about ${TP.mins(eff[d].secs)} min`), el("div", { class: "muted small" }, reasons[d])),
        runnerSeg(o, (r) => { if (r !== o) patchTrip(ui.tripId, { owners: { [d]: r }, pins: { [d]: true } }); })));
    }
    box.append(list);
    if (handed) box.append(el("p", { class: "muted small" }, `${plural(handed, "item")} handed over one by one stay with whoever has them.`));
    box.append(el("button", { class: "btn wide", disabled: store.readOnly, onclick: () => { patchTrip(ui.tripId, { owners: ownersFor(T, s.started ? "remaining" : "auto") }); toast(s.started ? "Rebalanced the work that’s left." : "Balanced. Departments you set stayed put."); } }, s.started ? "Rebalance what’s left" : "Balance automatically"),
      Object.values(T.pins || {}).some(Boolean) ? el("button", { class: "btn quiet", onclick: () => { const pins = Object.fromEntries(Object.keys(T.pins).map((d) => [d, false])); patchTrip(ui.tripId, { pins, owners: ownersFor({ ...T, pins: {} }, s.started ? "remaining" : "auto") }); } }, "Forget my choices and balance again") : null,
      el("button", { class: "btn primary wide", onclick: () => go(ui.me || "jere") }, "Start picking"));
    return box;
  }

  function vList(T, runner) {
    const all = linesOf(T).filter((l) => assignee(T, l) === runner);
    const s = stats(T).by[runner];
    const box = el("div", { class: "stack" },
      el("div", { class: "row" }, el("h1", { class: "grow who-" + runner }, `${RUNNERS[runner]}’s list`), el("button", { class: "btn quiet sm", onclick: () => go(other(runner)) }, `See ${RUNNERS[other(runner)]}’s`)), sampleNote(T));
    if (!all.length) { box.append(el("p", { class: "muted" }, linesOf(T).length ? `Nothing is assigned to ${RUNNERS[runner]} right now.` : "No items yet. Add orders to build the lists."), el("button", { class: "btn primary wide", onclick: () => go(linesOf(T).length ? "split" : "orders") }, linesOf(T).length ? "Split the work" : "Add orders")); return box; }
    box.append(el("div", {}, el("div", { class: "row", style: "margin-bottom:6px" }, el("span", { class: "grow", style: "font-weight:600" }, `${TP.fmtQty(s.got)} of ${TP.fmtQty(s.units)} units`), el("span", { class: "muted num" }, `${s.units ? Math.round((s.got / s.units) * 100) : 0}%`)), bar(s.units ? s.got / s.units : 0, runner)));
    if (ui.me && ui.me !== runner) box.append(el("div", { class: "banner plain" }, `You’re looking at ${RUNNERS[runner]}’s list. Anything you mark here counts for both of you.`));
    box.append(el("input", { class: "in", type: "search", placeholder: "Find an item or customer", value: ui.q, "aria-label": "Find an item or customer", "data-fk": "q", oninput: (e) => { ui.q = e.target.value; render(); } }));
    const q = TP.normName(ui.q);
    const shown = q ? all.filter((l) => TP.normName(`${l.n} ${l.b} ${custName(custOf(T, l.c))}`).includes(q)) : all;
    if (!shown.length) box.append(el("p", { class: "muted" }, "No items match that search."));
    const depts = [...new Set(shown.map((l) => l.d))].sort((a, b) => (DEPT[a] || DEPT.other).order - (DEPT[b] || DEPT.other).order);
    for (const d of depts) {
      const def = DEPT[d] || DEPT.other;
      const groups = new Map();
      for (const l of shown.filter((x) => x.d === d)) { const k = keyOf(l); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(l); }
      const arr = [...groups.entries()].map(([k, ls]) => ({ k: d + ":" + k, ls, done: ls.every(resolved) })).sort((a, b) => a.done - b.done);
      const left = arr.filter((g) => !g.done).length;
      const closed = ui.collapsed[runner + d] ?? false;
      const sec = el("section", { class: "dept" }, el("button", { class: "dept-h", "aria-expanded": String(!closed), onclick: () => { ui.collapsed[runner + d] = !closed; render(); } },
        el("span", { class: "ico", "aria-hidden": "true" }, def.icon), el("h2", {}, def.name), el("span", { class: "count num" }, left ? `${left} left` : "Done"), el("span", { class: "muted", "aria-hidden": "true" }, closed ? "+" : "−")));
      if (!closed) for (const g of arr) sec.append(pickRow(T, g, runner));
      box.append(sec);
    }
    if (s.units && s.got >= s.units) box.append(el("div", { class: "banner ok" }, "Everything on this list is handled."), el("button", { class: "btn primary wide", onclick: () => go("checkout") }, "Go to checkout"));
    return box;
  }
  function pickRow(T, g, runner) {
    const ls = g.ls, f = ls[0];
    const units = ls.reduce((n, l) => n + l.q, 0);
    const anyOos = ls.some((l) => l.st === "oos"), anyPart = ls.some((l) => l.st === "partial" || l.st === "needsub");
    const open = ui.openKey === g.k;
    const row = el("div", { class: "pick" + (g.done ? (ls.every((l) => l.st === "oos") ? " done oos" : " done") : anyPart || anyOos ? " part" : "") });
    row.append(el("div", { class: "qty num" }, el("div", {}, TP.fmtQty(units), ls.length > 1 ? el("small", {}, `${ls.length} bags`) : null)));
    row.append(el("button", { class: "body", "aria-expanded": String(open), onclick: () => { ui.openKey = open ? null : g.k; render(); } },
      el("div", { class: "name" }, f.n), el("div", { class: "meta" }, [f.s, f.b && !TP.normName(f.n).includes(TP.normName(f.b)) ? f.b : "", f.a ? "Aisle " + f.a : ""].filter(Boolean).join(", ")),
      el("div", { class: "tags" }, ls.map((l) => tag(T, l.c, ls.length > 1 || l.q !== 1 ? TP.fmtQty(l.q) + " for" : "For"))),
      ls.filter((l) => l.note).map((l) => el("div", { class: "note" }, `${custName(custOf(T, l.c))}: ${l.note}`)),
      ls.filter((l) => l.st && l.st !== "open" && l.st !== "picked").map((l) => el("div", { class: "note" }, `${custName(custOf(T, l.c))}: ${statusText(l)}`))));
    row.append(el("button", { class: "check", disabled: store.readOnly, "aria-label": g.done ? `Undo ${f.n}` : `Mark ${f.n} picked`, onclick: () => (g.done ? unpick(T, ls) : pick(T, ls.filter((l) => !resolved(l)))) }, el("span", { "aria-hidden": "true" }, "✓")));
    if (open) row.append(el("div", { class: "more" }, ls.map((l) => el("div", { class: "lineops stack" },
      el("div", { class: "row" }, el("div", { class: "grow" }, tag(T, l.c, TP.fmtQty(l.q) + " for")), el("span", { class: "muted small" }, `${RUNNERS[l.r]}’s Favor order`)),
      l.sub ? el("p", { class: "muted small" }, "If out: " + l.sub) : null,
      el("div", { class: "row" },
        l.q > 1 ? el("div", { class: "step" }, el("button", { "aria-label": "One fewer", onclick: () => setPicked(T, l, (resolved(l) && l.st === "picked" ? l.q : l.pk || 0) - 1) }, "−"), el("output", { class: "num" }, `${TP.fmtQty(l.st === "picked" ? l.q : l.pk || 0)} of ${TP.fmtQty(l.q)}`), el("button", { "aria-label": "One more", onclick: () => setPicked(T, l, (l.st === "picked" ? l.q : l.pk || 0) + 1) }, "+")) : null,
        el("button", { class: "btn sm", onclick: () => setLines(T, [l], l.st === "oos" ? { st: "open", pk: 0 } : { st: "oos", pk: 0 }) }, l.st === "oos" ? "Back in stock" : "Out of stock"),
        el("button", { class: "btn sm", onclick: () => subSheet(T, l) }, "Substitute"),
        el("button", { class: "btn sm", onclick: () => { patchTrip(ui.tripId, { lines: { [l.id]: { as: other(runner) } } }); toast(`Handed to ${RUNNERS[other(runner)]}.`); } }, `Give to ${RUNNERS[other(runner)]}`))))));
    return row;
  }
  const statusText = (l) => ({ partial: `${TP.fmtQty(l.pk || 0)} of ${TP.fmtQty(l.q)} so far`, oos: "out of stock", needsub: "needs a substitute", subbed: "substituted with " + (l.sn || "something else") }[l.st] || "");

  function vCheckout(T) {
    const ls = linesOf(T), box = el("div", { class: "stack" }, el("h1", {}, "Checkout"), sampleNote(T));
    if (!ls.length) { box.append(el("p", { class: "muted" }, "Nothing to check out yet.")); return box; }
    const cids = Object.keys(T.cust || {}).filter((cid) => ls.some((l) => l.c === cid));
    const state = (cid) => { const mine = ls.filter((l) => l.c === cid); const open = mine.filter((l) => !resolved(l) && l.st !== "partial"); return { mine, open, ok: !open.length && !!(T.ver && T.ver[cid] && T.ver[cid].ok) }; };
    const ready = cids.filter((cid) => state(cid).ok).length;
    box.append(el("div", { class: "banner " + (ready === cids.length ? "ok" : "plain") }, `${ready} of ${plural(cids.length, "order")} ready to scan. Sort the carts by bag letter, then scan each customer’s items under that customer’s own Favor order.`));
    for (const r of ["jere", "jesica"]) {
      const mineC = cids.filter((cid) => T.cust[cid].r === r);
      if (!mineC.length) continue;
      box.append(el("h2", { class: "who-" + r, style: "margin-top:22px" }, `Scan on ${RUNNERS[r]}’s Favor`));
      for (const cid of mineC) {
        const { mine, open, ok } = state(cid);
        const units = mine.reduce((n, l) => n + l.q, 0), got = mine.reduce((n, l) => n + (l.st === "picked" || l.st === "subbed" ? l.q : l.st === "partial" ? l.pk || 0 : 0), 0);
        const issues = mine.filter((l) => l.st === "oos" || l.st === "partial" || l.st === "subbed" || l.st === "needsub");
        const flagged = mine.filter((l) => l.fl && l.fl.length).length;
        const card = el("div", { class: "card stack" },
          el("div", { class: "row" }, el("div", { class: "grow" }, tag(T, cid)), el("span", { class: "pill " + (ok ? "ok" : open.length ? "bad" : "warn") }, ok ? "Ready to scan" : open.length ? `${open.length} still to pick` : "Check the bag")),
          el("p", { class: "num" }, `${TP.fmtQty(got)} of ${TP.fmtQty(units)} units in the cart, ${plural(mine.length, "line")}`),
          open.length ? el("div", { class: "banner bad" }, "Not picked yet: " + open.map((l) => `${TP.fmtQty(l.q)} × ${l.n} (${RUNNERS[assignee(T, l)]})`).join("; ")) : null,
          issues.length ? el("div", { class: "banner" }, issues.map((l) => `${l.n}: ${statusText(l)}`).join("; ") + ". Update the Favor order to match.") : null,
          flagged ? el("p", { class: "flagtxt" }, `${plural(flagged, "item")} on this order still marked to check on the Review screen.`) : null,
          el("details", {}, el("summary", {}, "All items on this order"), mine.map((l) => el("div", { class: "row small", style: "padding:5px 0;border-top:1px solid var(--line)" }, el("b", { class: "num", style: "width:34px" }, TP.fmtQty(l.q)), el("span", { class: "grow" }, l.n + (l.s ? ", " + l.s : "")), el("span", { class: "muted" }, l.st === "picked" ? `${RUNNERS[l.by] || RUNNERS[assignee(T, l)]} has it` : statusText(l) || `with ${RUNNERS[assignee(T, l)]}`)))),
          el("label", { class: "row", style: "font-weight:600;min-height:44px" }, el("input", { type: "checkbox", style: "width:24px;height:24px", checked: ok, disabled: !!open.length || store.readOnly, onchange: (e) => patchTrip(ui.tripId, { ver: { [cid]: { ok: e.target.checked, by: ui.me || "", at: Date.now() } } }) }), el("span", { class: "grow" }, open.length ? "Finish picking before checking this bag" : `I checked bag ${tagLetter(custOf(T, cid))} against this order`)));
        box.append(card);
      }
    }
    if (ready === cids.length && !T.done) box.append(el("button", { class: "btn primary wide", onclick: () => { patchTrip(ui.tripId, { done: true, t1: Date.now() }); toast("Trip finished."); } }, "Finish the trip"));
    if (T.done && T.t0 && T.t1) box.append(el("p", { class: "muted" }, `Finished. First pick to done took ${Math.round((T.t1 - T.t0) / 60000)} min (measured).`));
    return box;
  }

  /* ---------- sample orders (clearly labelled as made up) ---------- */
  function sampleTrip() {
    const raw = {
      "jere|Sydney": "H-E-B Whole Milk|1 gal|2|dairy;Large Grade A Eggs|12 ct|1|dairy;H-E-B Salted Butter|16 oz|1|dairy;Bananas|each|6|produce;Hass Avocados|each|4|produce;Roma Tomatoes|each|5|produce;Yellow Onion|each|2|produce;Boneless Skinless Chicken Breast|about 2 lb|1|meat;Ground Beef 80/20|1 lb|2|meat;Atlantic Salmon Fillet|about 1 lb|1|seafood;H-E-B Bakery Flour Tortillas|10 ct|1|bakery;Long Grain White Rice|2 lb|1|pantry;Black Beans|15 oz|3|canned;Tortilla Chips|13 oz|1|snacks;Mineral Water|12 pk|1|beverages;Paper Towels|6 rolls|1|household",
      "jere|Marcus": "Shredded Cheddar Cheese|8 oz|2|dairy;H-E-B Whole Milk|1/2 gal|1|dairy;Greek Yogurt Vanilla|5.3 oz|4|dairy;Sliced Oven Roasted Turkey|1/2 lb|1|deli|Sliced thin please;Baby Spinach|5 oz|1|produce;Bananas|each|4|produce;Lemons|each|3|produce;Thick Cut Bacon|16 oz|1|meat;Sourdough Loaf|each|1|bakery;Spaghetti|16 oz|2|pantry;Marinara Sauce|24 oz|1|pantry;Diced Tomatoes|14.5 oz|2|canned;Frozen Pepperoni Pizza|each|2|frozen;Vanilla Ice Cream|1.5 qt|1|frozen;Sparkling Water Lime|8 pk|2|beverages;Dish Soap|19 oz|1|cleaning",
      "jesica|Sherry": "Large Grade A Eggs|12 ct|2|dairy;Greek Yogurt Strawberry|5.3 oz|4|dairy;Unsalted Butter|16 oz|1|dairy;Strawberries|1 lb|2|produce;Red Bell Pepper|each|2|produce;Cilantro|bunch|1|produce;Rotisserie Chicken|each|1|prepared;Raw Peeled Shrimp|1 lb|1|seafood;Blueberry Muffins|4 ct|1|bakery;Honey Wheat Bread|20 oz|1|bakery;Creamy Peanut Butter|16 oz|1|pantry;Chicken Broth|32 oz|2|canned;Frozen Broccoli Florets|12 oz|2|frozen;Orange Juice No Pulp|52 oz|1|beverages;Shampoo|12 oz|1|hb;Toothpaste|4.8 oz|2|hb;Ibuprofen 200 mg|100 ct|1|pharmacy",
      "jesica|Dana": "H-E-B Whole Milk|1 gal|1|dairy;Sour Cream|16 oz|1|dairy;Hass Avocados|each|2|produce;Yellow Onion|each|3|produce;Jalapeño Peppers|each|4|produce;Ground Beef 80/20|1 lb|1|meat;Bone-In Pork Chops|about 1.5 lb|1|meat;Sliced Provolone|1/2 lb|1|deli;H-E-B Bakery Flour Tortillas|10 ct|2|bakery;Black Beans|15 oz|2|canned;Medium Salsa|16 oz|1|pantry;Tortilla Chips|13 oz|2|snacks;Frozen Waffles|10 ct|1|frozen;Cola|12 pk|1|beverages;Diapers Size 4|64 ct|1|baby;Dry Dog Food|15 lb|1|pet;Laundry Detergent|92 oz|1|cleaning;Trash Bags 13 gal|40 ct|1|household",
    };
    const T = { name: "Sample trip", store: "", createdAt: Date.now(), by: ui.me || "", sample: true, owners: {}, pins: {}, cust: {}, lines: {}, ver: {} };
    let t = 0, o = 1;
    for (const [who, rows] of Object.entries(raw)) {
      const [r, n] = who.split("|"); const cid = "c" + uid();
      T.cust[cid] = { n, r, t: t++ };
      for (const row of rows.split(";")) { const [name, s, q, d, note] = row.split("|"); T.lines["l" + uid()] = { n: name, b: "", s, q: Number(q), c: cid, r, d, a: "", note: note || "", sub: "", cf: 1, fl: [], src: "sample", st: "open", pk: 0, o: o++ }; }
    }
    const ids = Object.keys(T.lines);
    T.lines[ids[9]].fl = ["qty"]; T.lines[ids[40]].fl = ["conf"]; T.lines[ids[55]].fl = ["cut"];
    T.owners = ownersFor(T, "auto");
    return T;
  }

  /* ---------- shell ---------- */
  function setMe(r) { ui.me = r; lsSet("tp.me", r); render(); }
  function openTrip(id, view) {
    ui.tripId = id; lsSet("tp.trip", id); ui.q = ""; ui.openKey = null;
    const T = tripView(id);
    go(view || (T && linesOf(T).length ? ui.me || "jere" : "orders"));
  }
  function go(view) {
    ui.view = view; closeSheet();
    try { if (location.hash !== "#" + view) location.hash = view; } catch {}
    render(); window.scrollTo(0, 0);
  }
  window.addEventListener("hashchange", () => { const v = location.hash.slice(1); if (VIEWS.includes(v) && v !== ui.view) { ui.view = v; render(); window.scrollTo(0, 0); } });
  const NAV = [["orders", "Orders", "M12 5v14M5 12h14"], ["review", "Review", "M4 6h16M4 12h10M4 18h7M17 16l2 2 3-4"], ["split", "Split", "M12 3v18M5 8l-2 4 2 4M19 8l2 4-2 4"], ["list", "My list", "M9 6h11M9 12h11M9 18h11M4 6l1 1 2-2M4 12l1 1 2-2M4 18l1 1 2-2"], ["checkout", "Checkout", "M4 5h2l2 11h10l2-8H7M9 20h.01M17 20h.01"]];
  function render() {
    const active = document.activeElement, fk = active && active.dataset ? active.dataset.fk : null, selAt = fk ? active.selectionStart : null;
    const T = cur();
    if (!T && ui.view !== "home" && store.mode !== "loading") ui.view = "home";
    const v = T ? ui.view : "home";
    const top = document.getElementById("top");
    top.replaceChildren(el("div", { class: "top-in" },
      el("button", { class: "mark", onclick: () => go("home"), "aria-label": "TeamPick, all trips" }, "Team", el("i", {}, "Pick")),
      el("div", { class: "top-trip" }, T && v !== "home" ? [el("b", {}, [T.name, T.store].filter(Boolean).join(", ")), store.readOnly ? "View only" : store.mode === "cloud" ? (store.stale ? "May be out of date" : "Shared live") : "On this phone only"] : null),
      el("button", { class: "me " + (ui.me || ""), onclick: () => setMe(ui.me === "jere" ? "jesica" : "jere"), "aria-label": ui.me ? `You are ${RUNNERS[ui.me]}. Switch shopper` : "Choose who you are" }, ui.me ? RUNNERS[ui.me] : "Who are you?")));
    const main = document.getElementById("view");
    main.replaceChildren(v === "home" ? vHome() : v === "orders" ? vOrders(T) : v === "review" ? vReview(T) : v === "split" ? vSplit(T) : v === "checkout" ? vCheckout(T) : vList(T, v));
    if (store.readOnly && v !== "home") main.prepend(el("div", { class: "banner", style: "margin-bottom:14px" }, "You can see this trip but not change it. Ask the page’s owner to share it with you as an editor."));
    const nav = document.getElementById("nav");
    if (!T || v === "home") nav.hidden = true;
    else {
      nav.hidden = false;
      const flagged = stats(T).flagged;
      nav.replaceChildren(el("div", { class: "nav-in" }, NAV.map(([id, label, d]) => {
        const target = id === "list" ? ui.me || "jere" : id;
        const on = id === "list" ? v === "jere" || v === "jesica" : v === id;
        return el("button", { "aria-current": on ? "page" : null, onclick: () => go(target) }, icon(d), label, id === "review" && flagged ? el("span", { class: "badge" }, flagged) : null);
      })));
    }
    if (fk) { const again = document.querySelector(`[data-fk="${fk}"]`); if (again) { again.focus(); try { again.setSelectionRange(selAt, selAt); } catch {} } }
  }

  /* ---------- start ---------- */
  async function boot() {
    const h = location.hash.slice(1);
    if (VIEWS.includes(h)) ui.view = h;
    render();
    const use = (n) => { try { return window.claude && window.claude.use ? window.claude.use(n).catch(() => null) : Promise.resolve(null); } catch { return Promise.resolve(null); } };
    use("sample").then(async (s) => {
      cap.sample = s || null;
      if (s) { const lim = await s.limits().catch(() => null); cap.maxImages = (lim && lim.images && lim.images.maxCount) || 0; }
      cap.sampleReady = true; render();
    });
    use("user").then(async (u) => { if (!u) return; const can = await u.can("data.write"); if (can === false) { store.readOnly = true; render(); } });
    const db = await use("db");
    if (!db) {
      store.mode = "local"; store.snap = loadLocal();
      try { deptMap = JSON.parse(lsGet("tp.deptmap") || "{}") || {}; } catch {}
      render(); return;
    }
    cap.db = db;
    const timer = setTimeout(() => { store.stale = true; render(); }, 10000);
    db.collection("trips").orderBy("createdAt", "desc").limit(30).onSnapshot((snap) => {
      if (!snap.metadata.fromCache) { clearTimeout(timer); store.stale = false; }
      const next = {};
      for (const d of snap.docs) next[d.id] = d.data();
      store.snap = next; store.mode = "cloud";
      if (!snap.metadata.hasPendingWrites) for (const q of Object.values(Q)) if (!q.busy) q.settled = null;
      render();
    }, () => {
      clearTimeout(timer);
      store.mode = "local"; store.snap = loadLocal();
      toast("Shared trips can’t be reached. Anything you do now stays on this phone.");
      render();
    });
    db.doc("prefs/deptmap").onSnapshot((s) => { const m = s.exists ? s.data().m : null; deptMap = m && typeof m === "object" ? { ...m } : {}; }, () => {});
  }
  boot();
})();
